package com.example.demo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class OrderServiceImpl implements OrderService {
	private static List<Order> orders = new ArrayList<>();

	@Override
	public List<Order> getOrdersById(int id) {
		List<Order> corders = new ArrayList<Order>();
		for (Order o : orders) {
			if (o.getId() == id) {
				corders.add(o);
			}
		}
		return corders;
	}

	@Override
	public Order addOrder(Order order) {
		orders.add(order);
		return order;
	}

}
