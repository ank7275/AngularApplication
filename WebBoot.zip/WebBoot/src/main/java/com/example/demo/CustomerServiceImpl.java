package com.example.demo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import org.springframework.stereotype.Component;

@Component
public class CustomerServiceImpl implements CustomerService {

	private static List<Customer> customers = new ArrayList<>();

	@Override
	public List<Customer> getAllCustomer() {
		return customers;
	}

	@Override
	public Customer getCustomerById(int id) {
		for (Customer customer : customers) {
			if (customer.getId() == id) {
				return customer;
			}
		}
		return null;
	}

	@Override
	public Customer addCustomer(Customer customer) {
		Random random = new Random();
		int nextId = random.nextInt(1000) + 10;

		customer.setId(nextId);
		customers.add(customer);

		return customer;
	}

	@Override
	public void updateCustomer(Customer customer) {
		for (Customer oldCustomer : customers) {
			if (oldCustomer.getId() == customer.getId()) {
				oldCustomer.setAddress(customer.getAddress());
				oldCustomer.setCity(customer.getCity());
				oldCustomer.setPass(customer.getPass());
				oldCustomer.setState(customer.getState());
				oldCustomer.setZip(customer.getZip());
			}
		}
	}

	@Override
	public void deleteCustomer(int id) {
		Iterator<Customer> itr=customers.iterator();
		while(itr.hasNext()) {
			if(itr.next().getId()==id) {
				itr.remove();
				break;
			}
		}
	}

	@Override
	public List<Customer> getFilteredCustomer(String name) {
		List<Customer> filter = new ArrayList<Customer>();
		customers.stream().filter(p -> p.getEmail().contains(name)).forEach(p -> {
			filter.add(p);
		});
		return filter;

	}

}