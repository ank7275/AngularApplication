package com.example.demo;

import java.util.List;

public interface OrderService {
	 
	 public List<Order> getOrdersById(int id);
	 
	 public Order addOrder(Order order);
	 
}
