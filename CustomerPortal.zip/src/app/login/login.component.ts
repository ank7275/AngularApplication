import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl ,Validators} from '@angular/forms';
import { AuthService } from '../auth.service';
import { Router,ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  retUrl:string="login";
  feedback:string;
  loginInfo = new FormGroup({
    email: new FormControl('',Validators.required),
    password: new FormControl('',Validators.required)
  });
  constructor(private _auth: AuthService,
    private _router: Router,
    private activatedRoute:ActivatedRoute,) {
    }
    ngOnInit()
    {
      this.activatedRoute.queryParamMap
      .subscribe(params => {
        this.retUrl = params.get('retUrl');
        console.log( 'LoginComponent/ngOnInit '+ this.retUrl);
      });
    }
    onSubmit(){
      console.log(this.loginInfo.get('email').value);
      if(this._auth.login(this.loginInfo.get('email').value,this.loginInfo.get('password').value)==''){
         this.feedback="Invalid Credentials";
      }
    }
  }
