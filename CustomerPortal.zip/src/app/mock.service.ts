import { Injectable } from '@angular/core';
import { Customer } from './customers/customers';
import { Order } from './orders/orders';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError,Subject } from 'rxjs';
import { retry, catchError,map,tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class MockService {
  customers:Array<Customer>=[];
  orders:Array<Order>=[];
  private _refreshData$=new Subject<void>();

  get refreshData$(){
    return this._refreshData$;
  }
  constructor(private http:HttpClient) { }

  getCustomers():Observable<any>{
    return this.http.get("http://localhost:8070/api/customer/") .pipe(
      retry(1),
      catchError(this.handleError)
    );

  }
  saveCustomer(cust:Customer){
    this.http.post<Customer>("http://localhost:8070/api/addcustomer/",cust,{responseType:'text' as 'json'}).pipe(
      tap(()=>{this._refreshData$.next();})
    ).subscribe(
      data  => {
        console.log("POST Request is successful ", data);
      },
      error  => {

        console.log("Error", error);

      }
    );
  }

  saveOrders(order:Order){
    this.http.post<Customer>("http://localhost:8070/api/addorders/",order,{responseType:'text' as 'json'}).subscribe(
      data  => {
        console.log("POST Request is successful ", data);
      },
      error  => {

        console.log("Error", error);

      }
    );
  }
  getOrders(id:number):Observable<any>{
    return this.http.get("http://localhost:8070/api/getcorders/"+id) .pipe(
      retry(1),
      catchError(this.handleError)
    );
  }
  getCustomer(id:number):Observable<any>{
    return this.http.get("http://localhost:8070/api/customer/"+id) .pipe(
      retry(1),
      catchError(this.handleError)
    );
  }

  getfilteredData(name:string):Observable<any>{
    if(name==null || name==""){
      return this.http.get("http://localhost:8070/api/customer/") .pipe(
        retry(1),
        catchError(this.handleError)
      );

    }else{
      return this.http.get("http://localhost:8070/api/filtercustomer/"+name).pipe(
        retry(1),
        catchError(this.handleError)
      );
    }
  }

  deleteCustomer(id:number):Observable<any>{
    return this.http.get("http://localhost:8070/api/deletecustomer/"+id).pipe(
      retry(1),
      catchError(this.handleError)
    );
  }

  // Error handling
  handleError(error) {
    let errorMessage = '';
    if(error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    window.alert(errorMessage);
    return throwError(errorMessage);
  }
}
