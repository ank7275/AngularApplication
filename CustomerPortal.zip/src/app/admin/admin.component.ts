import { Component, OnInit } from '@angular/core';
import { MockService } from '../mock.service';
import { FormGroup, FormControl } from '@angular/forms';
import {  Customer } from '../customers/customers';
import {  Order } from '../orders/orders';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  _customers:any=[];
  customer:Customer;
  private order:Order;
  showModal:boolean;
  showModal1:boolean;
  selectedCust:number;
  price:number;
  custInfo = new FormGroup({
    email: new FormControl(''),
    address: new FormControl(''),
    state: new FormControl(''),
    city: new FormControl(''),
    zip: new FormControl(''),
    password: new FormControl('')
  });

  orderInfo = new FormGroup({
    user: new FormControl(''),
    item: new FormControl(''),
    price: new FormControl(''),
    qty: new FormControl(''),
    amt: new FormControl(''),
  });
  constructor(private _mock:MockService) { }

  ngOnInit(): void {
    this._mock.refreshData$.subscribe(()=>{this.getAllCustomers();});
    this.getAllCustomers();
    this.showModal1=false;
    this.showModal=false;
  }
  private getAllCustomers(){
    this._mock.getCustomers().subscribe((data) => {
      this._customers = data;
    });
  }
  onSubmit(){
    this.customer=new Customer(0,this.custInfo.get('email').value,this.custInfo.get('password').value,
    this.custInfo.get('address').value,this.custInfo.get('city').value,this.custInfo.get('state').value,this.custInfo.get('zip').value,);
    this._mock.saveCustomer(this.customer);
    this.custInfo.reset();
  }

  onSelect(id:number):void{
    this.selectedCust=id;
  }

  onSubmit1(){
    this.order=new Order(this.selectedCust,this.orderInfo.get('item').value,
    this.orderInfo.get('price').value,this.orderInfo.get('qty').value);
    this._mock.saveOrders(this.order);
    console.log(this.order);
    this.orderInfo.get('item').reset();
    this.orderInfo.get('price').reset();
    this.orderInfo.get('qty').reset();
    this.orderInfo.get('amt').reset();
  }

  changeItem(e){
    if(e.target.value==='sugar'){
      this.price=34;
    }else if(e.target.value==='tea'){
      this.price=45;
    }else if(e.target.value==='coffee'){
      this.price=55;
    }
    this.orderInfo.get('price').setValue(this.price, {
      onlySelf: true
    })
  }

  changeQty(e){
    let n:number=e.target.value;
    this.orderInfo.get('amt').setValue(n*this.price, {
      onlySelf: true
    })
  }

  deleteCustomer(id:number){
    this._mock.deleteCustomer(id).subscribe((data) => {
      this.getAllCustomers();
    });
  }
}
