import { Component, OnInit,Input } from '@angular/core';
import { MockService } from '../mock.service';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {
  @Input() public user;
  @Input() public uorders=[];
  display:boolean=false;


  constructor(private _mock:MockService) {

  }
  ngOnInit(): void {
    
  }
}
