export class Order{
  id:number;
  item:string;
  price:number;
  qty:number;
  amt:number;
  constructor(id:number,item:string,price:number,qty:number){
    this.id=id;
    this.item=item;
    this.price=price;
    this.qty=qty;
    this.amt=price*qty;
  }
}
