import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { of } from 'rxjs';
import { MockService } from './mock.service';
import { Router,ActivatedRoute } from '@angular/router';


@Injectable()
export class AuthService{

  private isloggedIn: string;
  private userName:string;
  private customers=[];
  constructor(private _router:Router) {
    this.isloggedIn='';
  }

  login(username: string, password:string){
    //Assuming users are provided the correct credentials.
    //In real app you will query the database to verify.
    if(username==='Admin'&&password==='Admin'){
      this.isloggedIn='admin';
      this._router.navigate(['admin']);
    }else if(username==='Customer'&&password==='Customer'){
      this.isloggedIn='customer';
      this._router.navigate(['customers']);
    }
    return this.isloggedIn;
  }

  isUserLoggedIn(): string {
    return this.isloggedIn;
  }

  isAdminUser():boolean {
    if (this.userName=='Admin') {
      return true;
    }
    return false;
  }

  logoutUser(): void{
    this.isloggedIn = '';
  }

}
