import { Component, OnInit,Input } from '@angular/core';
import { MockService } from '../mock.service';
import { FormGroup, FormControl,Validators } from '@angular/forms';
import {  Customer } from './customers';
import {NgxPaginationModule} from 'ngx-pagination';
import { HttpClient } from '@angular/common/http';
import {  Order } from '../orders/orders';
@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {
  public p:number=1;
  id:number=0;
  user:number;
  _customers:Customer[];
  private _searchText:string;
  orders=[];
  userOrders:Order[];
  customer:Customer;
  showModal:boolean;
  custInfo = new FormGroup({
    id: new FormControl(''),
    email: new FormControl('',[Validators.required]),
    address: new FormControl('',[Validators.required,Validators.minLength(10)]),
    state: new FormControl('',Validators.required),
    city: new FormControl('',[Validators.required,Validators.minLength(5)]),
    zip: new FormControl('',[Validators.required,Validators.minLength(6)]),
    password: new FormControl('',[Validators.required,Validators.minLength(5)])
  });
  constructor(private _mock:MockService,private http:HttpClient) {

  }

  get searchText(){
    return this._searchText;
  }

  set searchText(value:string){
    this._searchText=value;
    console.log(this._searchText);
    this._mock.getfilteredData(this._searchText).subscribe((data) => {
      this._customers = data;
    });
  }


  ngOnInit() {
    this._mock.refreshData$.subscribe(()=>{this.getAllCustomers();});
    this.getAllCustomers();
    this.showModal=false;
  }

  private getAllCustomers(){
    this._mock.getCustomers().subscribe((data) => {
      this._customers = data;
    });
  }

  onSubmit(){
    this.customer=new Customer(this.id,this.custInfo.get('email').value,this.custInfo.get('password').value,
    this.custInfo.get('address').value,this.custInfo.get('city').value,this.custInfo.get('state').value,this.custInfo.get('zip').value);
    this._mock.saveCustomer(this.customer);
    this.id=0;
    this.custInfo.reset();
    this.showModal=false;
  }

  viewOrders(id:number){
    this._mock.getOrders(id).subscribe((data) => {
      this.userOrders = data;
      this.user=id;
    });
    console.log(this.userOrders);
  }

  editCustomer(id:number){
    this.getCustomerData(id);
  }

  private getCustomerData(id:number){
    this._mock.getCustomer(id).subscribe((data) => {
      console.log(data);
      this.customer = data;
      this.id=id;
      this.patchData(this.customer);
    });
  }

  private patchData(customer:Customer){
    this.custInfo.patchValue({
      id:customer.id,
      email: customer.email,
      address: customer.address,
      state: customer.state,
      city: customer.city,
      zip: customer.zip,
      password: customer.pass
    });
  }

}
