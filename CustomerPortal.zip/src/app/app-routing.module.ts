import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { OrdersComponent } from './orders/orders.component';
import { CustomersComponent } from './customers/customers.component';
import { AdminComponent } from './admin/admin.component';
import {  AuthGuardService } from './auth-guard.service';
const routes: Routes = [
  {path:"login",component:LoginComponent},
  {path:"orders",component:OrdersComponent},
  {path:"customers",component:CustomersComponent,canActivate : [AuthGuardService] },
  {path:"admin",component:AdminComponent},
  {path:"edit/:id" ,component:CustomersComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routesComponent=[LoginComponent,OrdersComponent,CustomersComponent,AdminComponent];
