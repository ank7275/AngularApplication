import { Component } from '@angular/core';
import { AuthService } from './auth.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'CustomerPortal';
  constructor(private _auth:AuthService,private _router:Router){

  }
  
  logout(){
    console.log("logout");
    this._auth.logoutUser();
    this._router.navigate(['login']);
  }
}
