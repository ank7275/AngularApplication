import { Component, OnInit,Input } from '@angular/core';
import { MockService } from '../mock.service';
import { FormGroup, FormControl } from '@angular/forms';
import {  Customer } from './customers';
import {NgxPaginationModule} from 'ngx-pagination';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {
  read:boolean=false;
  public p:number=1;
  id:string;
  _customers=[];
  filteredCustomers=[];
  private _searchText:string;
  orders=[];
  userOrders=[];
  showModal2:boolean;
  private customer:Customer;
  showModal:boolean;
  custInfo = new FormGroup({
    email: new FormControl(''),
    address: new FormControl(''),
    state: new FormControl(''),
    city: new FormControl(''),
    zip: new FormControl(''),
    password: new FormControl('')
  });
  constructor(private _mock:MockService) {

  }

  get searchText(){
    return this._searchText;
  }

  set searchText(value:string){
    this._searchText=value;
    this.filteredCustomers=this.getfilteredData(value);
  }

  getfilteredData(value:string){
    return this._customers.filter(cust=>cust.email.toLowerCase().indexOf(value.toLowerCase())!==-1);
  }

  ngOnInit(): void {

    this._customers=this._mock.getCustomers();
    this.orders=this._mock.getOrders();
    this.showModal=false;
    this.showModal2=false;
    this.filteredCustomers=this._customers;
  }

  onSubmit(){
    this.customer=new Customer(this.custInfo.get('email').value,this.custInfo.get('password').value,
    this.custInfo.get('address').value,this.custInfo.get('city').value,this.custInfo.get('state').value,this.custInfo.get('zip').value);
    this._mock.saveCustomer(this.customer);
    this.custInfo.reset();
  }

  viewOrders(id:string){
    this.id=id;
    this.userOrders=[];
    for(let order of this.orders){
      if(order.user===this.id){
        this.userOrders.push(order);
      }
    }
    console.log(this.userOrders);
  }

  editCustomer(id:string){
    this.customer=this._mock.getCustomer(id);
    this.patchData(this.customer);
  }

  patchData(customer:Customer){
    this.custInfo.patchValue({
      email: customer.email,
      address: customer.address,
      state: customer.state,
      city: customer.city,
      zip: customer.zip,
      password: customer.pass
    });
  }

}
