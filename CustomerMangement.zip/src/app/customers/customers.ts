export class Customer{
  email:string;
  pass:string;
  address:string;
  state:string;
  zip:string;
  city:string;
  constructor(email:string,pass:string,address:string,city:string,state:string,zip:string){
    this.email=email;
    this.pass=pass;
    this.address=address;
    this.state=state;
    this.zip=zip;
    this.city=city;
  }
}
