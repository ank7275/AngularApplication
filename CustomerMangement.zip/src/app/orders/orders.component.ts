import { Component, OnInit,Input } from '@angular/core';
import { MockService } from '../mock.service';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {
  @Input() public user;
  @Input() public uorders=[];
  display:boolean=false;
  orders=[];

  constructor(private _mock:MockService) {

  }
  ngOnInit(): void {
    this.orders=this._mock.getOrders();

  }

  getUserOrders(){

  }
}
