export class Order{
  user:string;
  item:string;
  price:number;
  qty:number;
  amt:number;
  constructor(user:string,item:string,price:number,qty:number){
    this.user=user;
    this.item=item;
    this.price=price;
    this.qty=qty;
    this.amt=price*qty;
  }
}
