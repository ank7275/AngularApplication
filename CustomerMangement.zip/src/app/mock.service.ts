import { Injectable } from '@angular/core';
import { Customer } from './customers/customers';
import { Order } from './orders/orders';
@Injectable({
  providedIn: 'root'
})
export class MockService {
  customers:Array<Customer>=[];
  orders:Array<Order>=[];
  constructor() { }

  getCustomers(){
    return this.customers;
  }
  saveCustomer(cust:Customer){
    const index=this.customers.findIndex(e => e.email===cust.email);
    console.log(index);
    if(index<0){
      this.customers.push(cust);
    }else{
      this.customers[index] = cust;
    }
  }
  
  saveOrders(order:Order){
    this.orders.push(order);
  }
  getOrders(){
    return this.orders;
  }
  getCustomer(id:string){
    for(let cust of this.customers){
      if(cust.email===id){
        return cust;
      }
    }

  }

  updateCustomer(cust:Customer){

  }
}
